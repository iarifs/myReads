import React from 'react'

export default function Header(){
    return(
        <div className="list-books-title">
        <h1>MyReads</h1>
      </div>
    )
}